require('dotenv').config();
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const { rateLimit } = require('express-rate-limit');
const helmet = require('helmet');
const db = require('./db');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === 'production';
const appName = process.env.APP_NAME || 'Rex Trading & Auto';
const sessionDays = Math.max(1, Number(process.env.SESSION_DAYS || 7));
const uploadDir = path.join(__dirname, 'public', 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'blob:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'data:'],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'self'"]
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

const maxBytes = Math.max(1, Number(process.env.MAX_UPLOAD_MB || 8)) * 1024 * 1024;
const allowedMimes = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif']);
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    const safeExt = ['.jpg', '.jpeg', '.png', '.webp', '.gif'].includes(ext) ? ext : '.bin';
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${safeExt}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: maxBytes, files: 12 },
  fileFilter: (_req, file, cb) => {
    if (!allowedMimes.has(String(file.mimetype || '').toLowerCase())) return cb(new Error('Image type not allowed'));
    cb(null, true);
  }
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again later.' }
});

function text(value, max = 5000) { return String(value ?? '').trim().slice(0, max); }
function bool(value) { return value === true || value === 1 || value === '1' || value === 'true' || value === 'on'; }
function int(value, fallback = 0) {
  const n = Number(value);
  return Number.isInteger(n) ? n : fallback;
}
function safePage(value, fallback = 1) { return Math.max(1, int(value, fallback)); }
function safeLimit(value, fallback = 12, max = 48) { return Math.min(max, Math.max(1, int(value, fallback))); }
function hash(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function cleanupSessions() { db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now()); }
function getCookie(req, name) {
  const header = req.headers.cookie || '';
  for (const part of header.split(';')) {
    const [key, ...rest] = part.trim().split('=');
    if (key === name) return decodeURIComponent(rest.join('='));
  }
  return null;
}
function setCookie(res, name, value, maxAge) {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAge}`];
  if (isProd) parts.push('Secure');
  res.append('Set-Cookie', parts.join('; '));
}
function clearCookie(res, name) { setCookie(res, name, '', 0); }
function currentSession(req) {
  cleanupSessions();
  const raw = getCookie(req, 'rex_admin');
  if (!raw) return null;
  return db.prepare(`SELECT s.*, a.email FROM sessions s JOIN admins a ON a.id=s.admin_id WHERE s.token_hash=? AND s.expires_at>?`).get(hash(raw), Date.now());
}
function requireAdmin(req, res, next) {
  const session = currentSession(req);
  if (!session) return res.status(401).json({ error: 'Authentication required.' });
  req.session = session;
  next();
}
function requireCsrf(req, res, next) {
  const session = req.session || currentSession(req);
  if (!session) return res.status(401).json({ error: 'Authentication required.' });
  const incoming = req.get('X-CSRF-Token');
  if (!incoming || !crypto.timingSafeEqual(Buffer.from(hash(incoming)), Buffer.from(session.csrf_hash))) {
    return res.status(403).json({ error: 'Invalid security token.' });
  }
  next();
}
function validateImageFiles(req, res, next) {
  // Multer validates declared MIME; later code only serves from the isolated upload directory.
  next();
}
function deleteLocalFile(webPath) {
  if (!webPath || !webPath.startsWith('/uploads/')) return;
  const filePath = path.resolve(__dirname, 'public', webPath.slice(1));
  const root = path.resolve(uploadDir) + path.sep;
  if (filePath.startsWith(root) && fs.existsSync(filePath)) fs.unlinkSync(filePath);
}
function safeHttpUrl(value) {
  const v = text(value, 500);
  if (!v) return '';
  try { const u = new URL(v); return ['http:', 'https:'].includes(u.protocol) ? u.toString() : ''; } catch { return ''; }
}
function makeSlug(value) {
  return text(value, 100).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80) || `category-${Date.now()}`;
}
function uniqueSlug(name, excludeId = 0) {
  const base = makeSlug(name);
  let slug = base, n = 2;
  while (db.prepare('SELECT id FROM categories WHERE slug=? AND id<>?').get(slug, excludeId)) slug = `${base}-${n++}`;
  return slug;
}
function queryProducts(query) {
  const page = safePage(query.page);
  const limit = safeLimit(query.limit, 12, 48);
  const offset = (page - 1) * limit;
  const search = text(query.search, 100);
  const category = text(query.category, 100);
  const sort = text(query.sort, 30);
  let where = 'p.is_available=1';
  const params = [];
  if (category) { where += ' AND c.slug=?'; params.push(category); }
  if (search) {
    where += ` AND (p.title LIKE ? OR p.brand LIKE ? OR p.model LIKE ? OR p.location LIKE ?)`;
    const q = `%${search.replace(/[%_]/g, '\\$&')}%`;
    params.push(q, q, q, q);
  }
  let order = 'p.created_at DESC, p.id DESC';
  if (sort === 'oldest') order = 'p.created_at ASC, p.id ASC';
  if (sort === 'featured') order = 'p.is_featured DESC, p.created_at DESC, p.id DESC';
  if (sort === 'name') order = 'p.title COLLATE NOCASE ASC, p.id DESC';
  const total = db.prepare(`SELECT COUNT(*) AS count FROM products p JOIN categories c ON c.id=p.category_id WHERE ${where}`).get(...params).count;
  const rows = db.prepare(`SELECT p.*, c.name AS category_name, c.slug AS category_slug,
    (SELECT image FROM product_images pi WHERE pi.product_id=p.id ORDER BY pi.sort_order, pi.id LIMIT 1) AS gallery_image
    FROM products p JOIN categories c ON c.id=p.category_id WHERE ${where} ORDER BY ${order} LIMIT ? OFFSET ?`).all(...params, limit, offset);
  return { rows, total, page, limit, pages: Math.max(1, Math.ceil(total / limit)) };
}

app.get('/api/health', (_req, res) => res.json({ ok: true, app: appName, time: new Date().toISOString() }));
app.get('/api/site', (_req, res) => {
  const rows = db.prepare('SELECT key,value FROM site_settings').all();
  res.json(Object.fromEntries(rows.map(r => [r.key, r.value])));
});
app.get('/api/categories', (_req, res) => {
  res.json(db.prepare('SELECT * FROM categories ORDER BY sort_order ASC, id ASC').all());
});
app.get('/api/products', (req, res) => res.json(queryProducts(req.query)));
app.get('/api/products/featured', (_req, res) => {
  const rows = db.prepare(`SELECT p.*, c.name category_name, c.slug category_slug FROM products p JOIN categories c ON c.id=p.category_id WHERE p.is_available=1 AND p.is_featured=1 ORDER BY p.created_at DESC, p.id DESC LIMIT 8`).all();
  res.json(rows);
});
app.get('/api/products/:id', (req, res) => {
  const id = int(req.params.id);
  const product = db.prepare(`SELECT p.*, c.name category_name, c.slug category_slug FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=? AND p.is_available=1`).get(id);
  if (!product) return res.status(404).json({ error: 'Vehicle not found.' });
  const images = db.prepare('SELECT id,image FROM product_images WHERE product_id=? ORDER BY sort_order ASC,id ASC').all(id);
  const allImages = [...new Set([product.main_image, ...images.map(i => i.image)].filter(Boolean))];
  res.json({ ...product, images: allImages });
});
app.get('/api/posts', (_req, res) => res.json(db.prepare('SELECT * FROM posts WHERE is_published=1 ORDER BY created_at DESC,id DESC LIMIT 24').all()));
app.get('/api/posts/:id', (req, res) => {
  const post = db.prepare('SELECT * FROM posts WHERE id=? AND is_published=1').get(int(req.params.id));
  if (!post) return res.status(404).json({ error: 'Post not found.' });
  res.json(post);
});
app.get('/api/gallery', (_req, res) => res.json(db.prepare('SELECT * FROM gallery ORDER BY created_at DESC,id DESC LIMIT 60').all()));

app.post('/api/auth/login', loginLimiter, (req, res) => {
  const email = text(req.body.email, 200).toLowerCase();
  const password = String(req.body.password || '');
  const admin = db.prepare('SELECT * FROM admins WHERE email=?').get(email);
  if (!admin || !bcrypt.compareSync(password, admin.password_hash)) return res.status(401).json({ error: 'Invalid email or password.' });
  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(32).toString('hex');
  const expires = Date.now() + sessionDays * 24 * 60 * 60 * 1000;
  db.prepare('INSERT INTO sessions(token_hash,admin_id,csrf_hash,expires_at,created_at) VALUES(?,?,?,?,?)').run(hash(token), admin.id, hash(csrf), expires, Date.now());
  setCookie(res, 'rex_admin', token, sessionDays * 24 * 60 * 60);
  res.json({ ok: true, csrf, admin: { id: admin.id, email: admin.email } });
});
app.post('/api/auth/logout', (req, res) => {
  const raw = getCookie(req, 'rex_admin');
  if (raw) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(hash(raw));
  clearCookie(res, 'rex_admin');
  res.json({ ok: true });
});
app.get('/api/auth/me', requireAdmin, (req, res) => res.json({ authenticated: true, admin: { id: req.session.admin_id, email: req.session.email }, csrf: null }));
app.get('/api/auth/csrf', requireAdmin, (req, res) => {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('UPDATE sessions SET csrf_hash=? WHERE token_hash=?').run(hash(token), req.session.token_hash);
  res.json({ csrf: token });
});

app.get('/api/admin/dashboard', requireAdmin, requireCsrf, (_req, res) => {
  res.json({
    products: db.prepare('SELECT COUNT(*) c FROM products').get().c,
    activeProducts: db.prepare('SELECT COUNT(*) c FROM products WHERE is_available=1').get().c,
    featuredProducts: db.prepare('SELECT COUNT(*) c FROM products WHERE is_featured=1 AND is_available=1').get().c,
    posts: db.prepare('SELECT COUNT(*) c FROM posts').get().c,
    publishedPosts: db.prepare('SELECT COUNT(*) c FROM posts WHERE is_published=1').get().c,
    gallery: db.prepare('SELECT COUNT(*) c FROM gallery').get().c,
    categories: db.prepare('SELECT COUNT(*) c FROM categories').get().c
  });
});

app.get('/api/admin/products', requireAdmin, requireCsrf, (_req, res) => {
  const rows = db.prepare(`SELECT p.*,c.name category_name FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.created_at DESC,p.id DESC`).all();
  const imageStmt = db.prepare('SELECT id,image FROM product_images WHERE product_id=? ORDER BY sort_order,id');
  res.json(rows.map(p=>({...p,images:imageStmt.all(p.id)})));
});
app.post('/api/admin/products', requireAdmin, requireCsrf, upload.array('images', 12), validateImageFiles, (req, res) => {
  const categoryId = int(req.body.category_id);
  const title = text(req.body.title, 180);
  const cat = db.prepare('SELECT id FROM categories WHERE id=?').get(categoryId);
  if (!title || !cat) return res.status(400).json({ error: 'Vehicle title and category are required.' });
  const files = req.files || [];
  const category = db.prepare('SELECT id, slug FROM categories WHERE id=?').get(categoryId);
  const condition = category.slug === 'brand-new-bikes' ? 'Brand New' : 'Used';
  const mainImage = files[0] ? `/uploads/${files[0].filename}` : '';
  const insert = db.prepare(`INSERT INTO products(category_id,title,brand,model,year,price,condition,mileage,engine,transmission,fuel,color,location,description,main_image,is_featured,is_available)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const tx = db.transaction(() => {
    const result = insert.run(categoryId,title,text(req.body.brand,100),text(req.body.model,100),req.body.year ? int(req.body.year,null) : null,text(req.body.price,100),condition,text(req.body.mileage,100),text(req.body.engine,100),text(req.body.transmission,100),text(req.body.fuel,60),text(req.body.color,60),text(req.body.location,200),text(req.body.description,10000),mainImage,bool(req.body.is_featured)?1:0,bool(req.body.is_available)?1:0);
    const imageInsert = db.prepare('INSERT INTO product_images(product_id,image,sort_order) VALUES(?,?,?)');
    files.forEach((file, index) => imageInsert.run(result.lastInsertRowid, `/uploads/${file.filename}`, index));
    return Number(result.lastInsertRowid);
  });
  res.status(201).json({ id: tx() });
});
app.put('/api/admin/products/:id', requireAdmin, requireCsrf, upload.array('images', 12), validateImageFiles, (req, res) => {
  const id = int(req.params.id);
  const existing = db.prepare('SELECT * FROM products WHERE id=?').get(id);
  if (!existing) return res.status(404).json({ error: 'Vehicle not found.' });
  const categoryId = int(req.body.category_id);
  const title = text(req.body.title,180);
  if (!title || !db.prepare('SELECT id FROM categories WHERE id=?').get(categoryId)) return res.status(400).json({ error: 'Vehicle title and category are required.' });
  const files = req.files || [];
  const category = db.prepare('SELECT id, slug FROM categories WHERE id=?').get(categoryId);
  const condition = category.slug === 'brand-new-bikes' ? 'Brand New' : 'Used';
  const firstNewImage = files[0] ? `/uploads/${files[0].filename}` : '';
  const mainImage = existing.main_image || firstNewImage;
  const tx = db.transaction(() => {
    db.prepare(`UPDATE products SET category_id=?,title=?,brand=?,model=?,year=?,price=?,condition=?,mileage=?,engine=?,transmission=?,fuel=?,color=?,location=?,description=?,main_image=?,is_featured=?,is_available=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(
      categoryId,title,text(req.body.brand,100),text(req.body.model,100),req.body.year ? int(req.body.year,null):null,text(req.body.price,100),condition,text(req.body.mileage,100),text(req.body.engine,100),text(req.body.transmission,100),text(req.body.fuel,60),text(req.body.color,60),text(req.body.location,200),text(req.body.description,10000),mainImage,bool(req.body.is_featured)?1:0,bool(req.body.is_available)?1:0,id
    );
    if (files.length) {
      const maxOrder = db.prepare('SELECT COALESCE(MAX(sort_order),-1) m FROM product_images WHERE product_id=?').get(id).m;
      const imageInsert = db.prepare('INSERT INTO product_images(product_id,image,sort_order) VALUES(?,?,?)');
      files.forEach((file,index)=>imageInsert.run(id,`/uploads/${file.filename}`,maxOrder + index + 1));
    }
  });
  try { tx(); } catch (error) { for (const file of files) deleteLocalFile(`/uploads/${file.filename}`); return res.status(500).json({ error:'Unable to update vehicle.' }); }
  res.json({ ok:true });
});
app.delete('/api/admin/products/:id/images/:imageId', requireAdmin, requireCsrf, (req,res)=>{
  const productId=int(req.params.id); const imageId=int(req.params.imageId);
  const row=db.prepare('SELECT * FROM product_images WHERE id=? AND product_id=?').get(imageId,productId);
  if(!row) return res.status(404).json({error:'Vehicle photo not found.'});
  const product=db.prepare('SELECT main_image FROM products WHERE id=?').get(productId);
  db.prepare('DELETE FROM product_images WHERE id=?').run(imageId);
  if(product && product.main_image===row.image){
    const replacement=db.prepare('SELECT image FROM product_images WHERE product_id=? ORDER BY sort_order,id LIMIT 1').get(productId);
    db.prepare('UPDATE products SET main_image=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(replacement?.image || '',productId);
  }
  deleteLocalFile(row.image);
  res.json({ok:true});
});
app.delete('/api/admin/products/:id', requireAdmin, requireCsrf, (req,res)=>{
  const id=int(req.params.id); const existing=db.prepare('SELECT main_image FROM products WHERE id=?').get(id);
  if(!existing) return res.status(404).json({error:'Vehicle not found.'});
  const images=db.prepare('SELECT image FROM product_images WHERE product_id=?').all(id).map(x=>x.image);
  db.prepare('DELETE FROM products WHERE id=?').run(id);
  [existing.main_image,...images].forEach(deleteLocalFile);
  res.json({ok:true});
});

app.get('/api/admin/posts', requireAdmin, requireCsrf, (_req,res)=>res.json(db.prepare('SELECT * FROM posts ORDER BY created_at DESC,id DESC').all()));
app.post('/api/admin/posts', requireAdmin, requireCsrf, upload.single('image'), (req,res)=>{
  const title=text(req.body.title,180); if(!title) return res.status(400).json({error:'Post title is required.'});
  const image=req.file?`/uploads/${req.file.filename}`:'';
  const result=db.prepare('INSERT INTO posts(title,excerpt,content,image,is_published) VALUES(?,?,?,?,?)').run(title,text(req.body.excerpt,500),text(req.body.content,12000),image,bool(req.body.is_published)?1:0);
  res.status(201).json({id:Number(result.lastInsertRowid)});
});
app.put('/api/admin/posts/:id', requireAdmin, requireCsrf, upload.single('image'), (req,res)=>{
  const id=int(req.params.id); const existing=db.prepare('SELECT * FROM posts WHERE id=?').get(id); if(!existing) return res.status(404).json({error:'Post not found.'});
  const title=text(req.body.title,180); if(!title) return res.status(400).json({error:'Post title is required.'});
  const image=req.file?`/uploads/${req.file.filename}`:existing.image;
  db.prepare('UPDATE posts SET title=?,excerpt=?,content=?,image=?,is_published=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(title,text(req.body.excerpt,500),text(req.body.content,12000),image,bool(req.body.is_published)?1:0,id);
  if(req.file) deleteLocalFile(existing.image);
  res.json({ok:true});
});
app.delete('/api/admin/posts/:id', requireAdmin, requireCsrf, (req,res)=>{
  const id=int(req.params.id); const existing=db.prepare('SELECT image FROM posts WHERE id=?').get(id); if(!existing) return res.status(404).json({error:'Post not found.'});
  db.prepare('DELETE FROM posts WHERE id=?').run(id); deleteLocalFile(existing.image); res.json({ok:true});
});

app.get('/api/admin/gallery', requireAdmin, requireCsrf, (_req,res)=>res.json(db.prepare('SELECT * FROM gallery ORDER BY created_at DESC,id DESC').all()));
app.post('/api/admin/gallery', requireAdmin, requireCsrf, upload.array('images',12), (req,res)=>{
  const files=req.files||[]; if(!files.length) return res.status(400).json({error:'Choose at least one image.'});
  const insert=db.prepare('INSERT INTO gallery(title,image,caption) VALUES(?,?,?)');
  const tx=db.transaction(()=>files.map(f=>insert.run(text(req.body.title,180),`/uploads/${f.filename}`,text(req.body.caption,500)).lastInsertRowid));
  res.status(201).json({ids:tx()});
});
app.put('/api/admin/gallery/:id', requireAdmin, requireCsrf, upload.single('image'), (req,res)=>{
  const id=int(req.params.id); const existing=db.prepare('SELECT * FROM gallery WHERE id=?').get(id); if(!existing) return res.status(404).json({error:'Gallery image not found.'});
  const image=req.file?`/uploads/${req.file.filename}`:existing.image;
  db.prepare('UPDATE gallery SET title=?,image=?,caption=? WHERE id=?').run(text(req.body.title,180),image,text(req.body.caption,500),id);
  if(req.file) deleteLocalFile(existing.image); res.json({ok:true});
});
app.delete('/api/admin/gallery/:id', requireAdmin, requireCsrf, (req,res)=>{
  const id=int(req.params.id); const existing=db.prepare('SELECT image FROM gallery WHERE id=?').get(id); if(!existing) return res.status(404).json({error:'Gallery image not found.'});
  db.prepare('DELETE FROM gallery WHERE id=?').run(id); deleteLocalFile(existing.image); res.json({ok:true});
});

app.get('/api/admin/categories', requireAdmin, requireCsrf, (_req,res)=>res.json(db.prepare('SELECT * FROM categories ORDER BY sort_order,id').all()));
app.post('/api/admin/categories', requireAdmin, requireCsrf, (req,res)=>{
  const name=text(req.body.name,100); if(!name) return res.status(400).json({error:'Category name is required.'});
  const slug=uniqueSlug(req.body.slug||name); const result=db.prepare('INSERT INTO categories(name,slug,description,sort_order) VALUES(?,?,?,?)').run(name,slug,text(req.body.description,500),int(req.body.sort_order,0));
  res.status(201).json({id:Number(result.lastInsertRowid)});
});
app.put('/api/admin/categories/:id', requireAdmin, requireCsrf, (req,res)=>{
  const id=int(req.params.id); if(!db.prepare('SELECT id FROM categories WHERE id=?').get(id)) return res.status(404).json({error:'Category not found.'});
  const name=text(req.body.name,100); if(!name) return res.status(400).json({error:'Category name is required.'});
  db.prepare('UPDATE categories SET name=?,slug=?,description=?,sort_order=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(name,uniqueSlug(req.body.slug||name,id),text(req.body.description,500),int(req.body.sort_order,0),id); res.json({ok:true});
});
app.delete('/api/admin/categories/:id', requireAdmin, requireCsrf, (req,res)=>{
  const id=int(req.params.id); const count=db.prepare('SELECT COUNT(*) c FROM products WHERE category_id=?').get(id).c; if(count) return res.status(409).json({error:'Cannot delete a category that still contains vehicles.'});
  const result=db.prepare('DELETE FROM categories WHERE id=?').run(id); if(!result.changes) return res.status(404).json({error:'Category not found.'}); res.json({ok:true});
});

app.get('/api/admin/settings', requireAdmin, requireCsrf, (_req,res)=>{
  const rows=db.prepare('SELECT key,value FROM site_settings').all(); res.json(Object.fromEntries(rows.map(r=>[r.key,r.value])));
});
app.put('/api/admin/settings', requireAdmin, requireCsrf, upload.single('logo'), (req,res)=>{
  const allowed=['business_name','tagline','hero_title','hero_subtitle','phone_1','phone_2','whatsapp','email','address','opening_hours','facebook','instagram','youtube','primary_color','accent_color'];
  const oldLogo=db.prepare('SELECT value FROM site_settings WHERE key="logo_path"').get()?.value || '';
  const stmt=db.prepare('INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  const tx=db.transaction(()=>{
    allowed.forEach(k=>{
      if (['facebook','instagram','youtube'].includes(k)) stmt.run(k,safeHttpUrl(req.body[k]));
      else stmt.run(k,text(req.body[k],500));
    });
    if(req.file) stmt.run('logo_path',`/uploads/${req.file.filename}`);
  });
  tx(); if(req.file) deleteLocalFile(oldLogo); res.json({ok:true});
});

app.use(express.static(path.join(__dirname,'public'), { extensions:['html'] }));
app.get('/*splat', (req,res,next)=>{
  if(req.path.startsWith('/api/')) return next();
  if(req.path.startsWith('/admin')) return res.sendFile(path.join(__dirname,'public','admin.html'));
  res.sendFile(path.join(__dirname,'public','index.html'));
});

app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: `Upload error: ${err.message}` });
  if (err && err.message === 'Image type not allowed') return res.status(400).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(PORT,()=>console.log(`${appName} running on http://localhost:${PORT}`));
