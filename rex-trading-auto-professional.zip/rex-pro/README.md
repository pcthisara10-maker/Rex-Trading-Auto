# Rex Trading & Auto — Full-stack Vehicle Website

A professional starter implementation for **Rex Trading & Auto** with a public vehicle marketplace, REST API, SQLite database, image uploads and a secure admin CMS.

## Vehicle structure

1. Brand New Bikes
2. Used Bikes
3. Used Cars
4. Used Vans
5. Used Three Wheelers
6. Used Lorries

Only bikes have the **brand-new** category. The other vehicle categories are intended for **used / second-hand vehicles**, matching the brief provided for the project.

## Stack

- Node.js + Express 5
- SQLite + better-sqlite3
- bcryptjs password hashing
- Multer image uploads
- Helmet security headers
- Rate limiting on admin login
- Server-side sessions with hashed tokens and CSRF token protection
- Responsive vanilla HTML/CSS/JavaScript frontend and admin panel

The dependency versions in `package.json` were checked against npm's current package pages on 2026-09-27.

## Install

1. Install Node.js 18 or newer.
2. Copy `.env.example` to `.env`.
3. Set a real admin email and a strong admin password of at least 8 characters.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000`.
7. Open `http://localhost:3000/admin` for the CMS.

## Admin CMS

The admin panel supports:

- Add/edit/delete vehicle listings
- Upload/replace up to 12 vehicle photos
- Featured and live/hidden status
- Add/edit/delete posts
- Upload/edit/delete gallery photos
- Add/edit/delete categories
- Update logo, hero copy, contact details and social URLs

## Logo

The current `public/images/logo-placeholder.svg` is deliberately a placeholder. Upload the real Rex Trading & Auto logo from **Admin → Settings** once available.

## Production notes

For public deployment, use HTTPS, a strong secret/password policy, regular database and upload backups, and a reverse proxy such as Nginx or the hosting platform's managed HTTPS layer.
