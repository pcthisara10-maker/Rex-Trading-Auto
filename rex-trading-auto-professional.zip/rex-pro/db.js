const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');

const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(path.join(dataDir, 'rex-trading-auto.db'));
db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');
db.pragma('busy_timeout = 5000');

db.exec(`
CREATE TABLE IF NOT EXISTS admins (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  category_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  brand TEXT NOT NULL DEFAULT '',
  model TEXT NOT NULL DEFAULT '',
  year INTEGER,
  price TEXT NOT NULL DEFAULT '',
  condition TEXT NOT NULL DEFAULT 'Used',
  mileage TEXT NOT NULL DEFAULT '',
  engine TEXT NOT NULL DEFAULT '',
  transmission TEXT NOT NULL DEFAULT '',
  fuel TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '',
  location TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  main_image TEXT NOT NULL DEFAULT '',
  is_featured INTEGER NOT NULL DEFAULT 0,
  is_available INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  image TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS posts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  excerpt TEXT NOT NULL DEFAULT '',
  content TEXT NOT NULL DEFAULT '',
  image TEXT NOT NULL DEFAULT '',
  is_published INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS gallery (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL DEFAULT '',
  image TEXT NOT NULL,
  caption TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS site_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  admin_id INTEGER NOT NULL,
  csrf_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY(admin_id) REFERENCES admins(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_available ON products(is_available);
CREATE INDEX IF NOT EXISTS idx_products_featured ON products(is_featured);
CREATE INDEX IF NOT EXISTS idx_product_images_product ON product_images(product_id);
CREATE INDEX IF NOT EXISTS idx_posts_published ON posts(is_published);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
`);

function hasColumn(table, column) {
  return db.prepare(`PRAGMA table_info(${table})`).all().some(row => row.name === column);
}

const migrations = [
  ['products', 'transmission', 'ALTER TABLE products ADD COLUMN transmission TEXT NOT NULL DEFAULT \'\''],
  ['products', 'fuel', 'ALTER TABLE products ADD COLUMN fuel TEXT NOT NULL DEFAULT \'\''],
  ['products', 'color', 'ALTER TABLE products ADD COLUMN color TEXT NOT NULL DEFAULT \'\''],
  ['categories', 'updated_at', "ALTER TABLE categories ADD COLUMN updated_at TEXT NOT NULL DEFAULT ''"],
  ['sessions', 'csrf_hash', 'ALTER TABLE sessions ADD COLUMN csrf_hash TEXT NOT NULL DEFAULT \'\'']
];
for (const [table, column, sql] of migrations) {
  if (!hasColumn(table, column)) db.exec(sql);
}

db.exec(`CREATE TABLE IF NOT EXISTS product_images (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  image TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
)`);

db.exec(`
DELETE FROM sessions WHERE expires_at < ${Date.now()};
`);

const defaultCategories = [
  ['Brand New Bikes', 'brand-new-bikes', 'Brand new motorcycles and bikes.', 1],
  ['Used Bikes', 'used-bikes', 'Second-hand motorcycles and bikes.', 2],
  ['Used Cars', 'used-cars', 'Second-hand cars.', 3],
  ['Used Vans', 'used-vans', 'Second-hand vans.', 4],
  ['Used Three Wheelers', 'used-three-wheelers', 'Second-hand three-wheelers.', 5],
  ['Used Lorries', 'used-lorries', 'Second-hand lorries.', 6]
];
const insertCategory = db.prepare(`INSERT OR IGNORE INTO categories (name, slug, description, sort_order) VALUES (?, ?, ?, ?)`);
for (const c of defaultCategories) insertCategory.run(...c);

const defaultSettings = {
  business_name: 'Rex Trading & Auto',
  tagline: 'New bikes and quality used vehicles in one trusted place.',
  hero_title: 'Find the right vehicle for your next journey.',
  hero_subtitle: 'Explore brand new bikes and quality second-hand vehicles with Rex Trading & Auto.',
  phone_1: '',
  phone_2: '',
  whatsapp: '',
  email: '',
  address: '',
  opening_hours: '',
  logo_path: '/images/logo-placeholder.svg',
  hero_image: '',
  primary_color: '#0c1016',
  accent_color: '#e11d2e',
  facebook: '',
  instagram: '',
  youtube: ''
};
const insertSetting = db.prepare('INSERT OR IGNORE INTO site_settings (key, value) VALUES (?, ?)');
for (const [key, value] of Object.entries(defaultSettings)) insertSetting.run(key, value);

const adminEmail = String(process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const adminPassword = String(process.env.ADMIN_PASSWORD || '');
if (adminEmail && adminPassword && adminPassword.length >= 8) {
  const existing = db.prepare('SELECT id FROM admins WHERE email=?').get(adminEmail);
  if (!existing) {
    db.prepare('INSERT INTO admins (email, password_hash) VALUES (?, ?)').run(adminEmail, bcrypt.hashSync(adminPassword, 12));
  }
}

module.exports = db;
